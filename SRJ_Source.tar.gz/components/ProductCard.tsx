import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';
import { Product } from '../lib/types';

interface Props {
  product: Product;
  onPress: () => void;
  onAddToWishlist: () => void;
  onAddToCart: () => void;
  isWishlisted: boolean;
}

export default function ProductCard({ product, onPress, onAddToWishlist, onAddToCart, isWishlisted }: Props) {
  const scale = useSharedValue(1);
  const heartScale = useSharedValue(1);

  const cardStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const heartStyle = useAnimatedStyle(() => ({ transform: [{ scale: heartScale.value }] }));

  const onCardPressIn = () => { scale.value = withSpring(0.97, { damping: 15, stiffness: 200 }); };
  const onCardPressOut = () => { scale.value = withSpring(1, { damping: 15, stiffness: 200 }); };

  const pressWishlist = () => {
    heartScale.value = withSpring(1.35, { damping: 10, stiffness: 250 });
    setTimeout(() => { heartScale.value = withSpring(1, { damping: 14, stiffness: 200 }); }, 120);
    onAddToWishlist();
  };

  const pressCart = () => {
    onAddToCart();
  };

  return (
    <Animated.View style={[styles.cardWrap, cardStyle]}>
      <TouchableOpacity activeOpacity={1} onPressIn={onCardPressIn} onPressOut={onCardPressOut} onPress={onPress}>
        <View style={[styles.iconContainer, { backgroundColor: product.color + '18' }]}>
          <Ionicons name={product.icon as any} size={42} color={product.color} />
        </View>
        <View style={styles.content}>
          <Text style={styles.category}>{product.category}</Text>
          <Text style={styles.name} numberOfLines={2}>{product.name}</Text>
          <Text style={styles.desc} numberOfLines={1}>{product.description}</Text>
          <View style={styles.metaRow}>
            <Text style={styles.weight}>{product.weight}g • {product.purity}</Text>
          </View>
          <Text style={styles.price}>₹{product.price.toLocaleString('en-IN')}</Text>
        </View>
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionBtn} activeOpacity={0.88} onPress={pressWishlist}>
            <Animated.View style={heartStyle}>
              <Ionicons name={isWishlisted ? 'heart' : 'heart-outline'} size={18} color={isWishlisted ? '#8F5155' : '#8C5C2D'} />
            </Animated.View>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionBtn, styles.cartBtn]} activeOpacity={0.88} onPress={pressCart}>
            <Ionicons name="cart" size={18} color="#F8F3ED" />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  cardWrap: { width: '47%', margin: 6 },
  card: { backgroundColor: '#FFF8F0', borderRadius: 18, overflow: 'hidden', borderWidth: 1, borderColor: '#D9C9B8' },
  iconContainer: { height: 100, alignItems: 'center', justifyContent: 'center' },
  content: { padding: 14 },
  category: { fontSize: 10, color: '#B17C7F', fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1.5 },
  name: { fontSize: 15, color: '#1F1414', fontWeight: '800', marginTop: 5, lineHeight: 19, letterSpacing: 0.2 },
  desc: { fontSize: 11, color: '#7A5C5C', marginTop: 3, letterSpacing: 0.1 },
  metaRow: { flexDirection: 'row', marginTop: 7 },
  weight: { fontSize: 11, color: '#8C5C2D', fontWeight: '600', letterSpacing: 0.5 },
  price: { fontSize: 17, color: '#8C5C2D', fontWeight: '900', marginTop: 9, letterSpacing: 0.3 },
  actions: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#D9C9B8' },
  actionBtn: { flex: 1, paddingVertical: 11, alignItems: 'center', justifyContent: 'center' },
  cartBtn: { backgroundColor: '#7A4B6A' },
});