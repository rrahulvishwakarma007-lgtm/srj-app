import React, { useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming, withDelay, withRepeat,
  withSequence, withSpring, Easing, runOnJS
} from 'react-native-reanimated';

const { width, height } = Dimensions.get('window');

const MAIN = 'SRJ THE APP';
const SUB = 'By Shekhar Raja Jewellers';

interface Props { onFinish: () => void; }

function FloatingLetter({ char, index, total }: { char: string; index: number; total: number }) {
  const y = useSharedValue(0);
  const rot = useSharedValue(0);
  const delay = index * 70;

  useEffect(() => {
    // STRONG visible float for mobile — bigger amplitude, slower graceful
    y.value = withDelay(delay, withRepeat(
      withSequence(
        withTiming(-18, { duration: 1300, easing: Easing.inOut(Easing.sin) }),
        withTiming(14, { duration: 1500, easing: Easing.inOut(Easing.sin) })
      ), -1, true
    ));
    rot.value = withDelay(delay + 100, withRepeat(
      withSequence(withTiming(-6, { duration: 1400 }), withTiming(6, { duration: 1500 })),
      -1, true
    ));
  }, []);

  const style = useAnimatedStyle(() => ({
    transform: [{ translateY: y.value }, { rotate: rot.value + 'deg' }],
  }));

  return <Animated.Text style={[styles.letter, style]}>{char === ' ' ? '\u00A0' : char}</Animated.Text>;
}

export default function IntroScreen({ onFinish }: Props) {
  const fade = useSharedValue(0);
  const slide = useSharedValue(50);
  const iconScale = useSharedValue(0.5);
  const iconRot = useSharedValue(-25);

  const subStyle = useAnimatedStyle(() => ({ opacity: fade.value, transform: [{ translateY: slide.value }] }));
  const iconStyle = useAnimatedStyle(() => ({ transform: [{ scale: iconScale.value }, { rotate: iconRot.value + 'deg' }] }));

  useEffect(() => {
    iconScale.value = withDelay(120, withSpring(1, { damping: 10, stiffness: 80 }));
    iconRot.value = withDelay(120, withSpring(0, { damping: 12, stiffness: 70 }));
    fade.value = withDelay(700, withTiming(1, { duration: 800, easing: Easing.out(Easing.quad) }));
    slide.value = withDelay(700, withTiming(0, { duration: 800, easing: Easing.out(Easing.quad) }));
    const t = setTimeout(() => finish(), 5200);
    return () => clearTimeout(t);
  }, []);

  const finish = () => {
    fade.value = withTiming(0, { duration: 380 });
    slide.value = withTiming(25, { duration: 380 });
    setTimeout(() => runOnJS(onFinish)(), 420);
  };

  // Royal gradient background: Top #4B2E83 → Bottom #2A1B4D + subtle pink glow
  return (
    <View style={styles.container}>
      <View style={styles.gradTop} />
      <View style={styles.gradBottom} />
      <View style={styles.glow} />

      <TouchableOpacity style={styles.skip} onPress={finish} activeOpacity={0.7}><Text style={styles.skipText}>Skip</Text></TouchableOpacity>

      <View style={styles.center}>
        <Animated.View style={[styles.iconWrap, iconStyle]}><Ionicons name="diamond" size={72} color="#C2185B" /></Animated.View>
        <View style={styles.mainRow}>
          {MAIN.split('').map((ch, i) => <FloatingLetter key={i} char={ch} index={i} total={MAIN.length} />)}
        </View>
        <Animated.Text style={[styles.sub, subStyle]}>{SUB}</Animated.Text>
      </View>

      <TouchableOpacity style={styles.enter} onPress={finish} activeOpacity={0.85}><Text style={styles.enterText}>ENTER THE SHOWROOM</Text></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#2A1B4D', alignItems: 'center', justifyContent: 'center' },
  gradTop: { position: 'absolute', top: 0, left: 0, right: 0, height: '68%', backgroundColor: '#4B2E83' },
  gradBottom: { position: 'absolute', bottom: 0, left: 0, right: 0, height: '42%', backgroundColor: '#2A1B4D' },
  glow: { position: 'absolute', top: 0, left: 0, right: 0, height: '40%', backgroundColor: 'rgba(194,24,91,0.08)' },
  skip: { position: 'absolute', top: 50, right: 24, padding: 8 },
  skipText: { color: '#C2185B', fontSize: 14, fontWeight: '700', letterSpacing: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  iconWrap: { marginBottom: 16 },
  mainRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  letter: { color: '#F2E9F5', fontSize: 36, fontWeight: '900', letterSpacing: 3, marginHorizontal: 1, textShadowColor: 'rgba(194,24,91,0.35)', textShadowOffset: { width: 0, height: 2 }, textShadowRadius: 6 },
  sub: { color: '#C2185B', fontSize: 15, fontWeight: '700', letterSpacing: 3, marginTop: 16, textAlign: 'center' },
  enter: { position: 'absolute', bottom: 68, backgroundColor: '#C2185B', paddingVertical: 15, paddingHorizontal: 36, borderRadius: 30, shadowColor: '#C2185B', shadowOpacity: 0.35, shadowRadius: 12, elevation: 6 },
  enterText: { color: '#F2E9F5', fontSize: 13, fontWeight: '800', letterSpacing: 2 },
});